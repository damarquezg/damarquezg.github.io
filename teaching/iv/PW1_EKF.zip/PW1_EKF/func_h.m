function [y] = func_h(x)

% range and bearing
px = x(1);
py = x(2);

d = sqrt(px^2 + py^2);
a = atan2(py, px);

y = [d;a];

end