%  state: position and velocity
%  x = [px py vx vy]'
%
%    position
%    px+ = px + vx*dt
%    py+ = py + vy*dt
%
%    velocity
%    vx+ = vx + ax*dt + nx
%    vy+ = vy + ay*dt + ny

function [xo] = move(x, u, n, dt)

px = x(1);
py = x(2);
vx = x(3);
vy = x(4);
ax = u(1);
ay = u(2);
nx = n(1);
ny = n(2);

px = px + vx*dt;
py = py + vy*dt;
vx = vx + ax*dt + nx;
vy = vy + ay*dt + ny;

xo = [px;py;vx;vy];

end
