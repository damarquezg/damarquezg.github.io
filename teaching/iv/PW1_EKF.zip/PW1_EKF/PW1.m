%  Two-dimensional tracker
%
%  System definition
%
%    state: position and velocity
%    x = [px py vx vy]'
%
%      position
%      px+ = px + vx*dt
%      py+ = py + vy*dt
%
%      velocity
%      vx+ = vx + ax*dt + nx
%      vy+ = vy + ay*dt + ny
%    
%      control input
%      u = [ax, ay]'
%
%      velocity noise
%      n = [nx, ny]'
%
%    measurement vector: range and bearing
%    y = [d, a]'
%
%      distance (from the origin to the position)
%      d = sqrt(px^2 + py^2) + rd
%
%      angle (alpha)
%      a = atan2(py, px) + ra
%
%      measurement noise
%      r = [rd, ra]'

%  Some system initializations
dt = 0.1;
tt = 0:dt:4;

% Covariance matrix
Q = diag([.1 0.1].^2); % propiocetvite
R = diag([.1 1*pi/180].^2); % exteroceptive

% Simulated variables
X = [2 1 -1 1]';

% Estimated variables
x = [3 3 0 0]';

% perturbation levels
q = sqrt(diag(Q)) / 2;
r = sqrt(diag(R)) / 2;

% START LOOP
for t = tt
    % read control
    switch t
        case 1
            u = [2 0]'/dt;
        case 2
            u = [-3 0]'/dt;
        case 3
            u = [1 -2]'/dt;
        otherwise
            u = [0 0]'/dt;
    end
    
    % SIMULATE
    % move
    n = q .* randn(2,1);
    X = move(X, u, n, dt);
    % measurement (range and bearing)
    v = r .* randn(2,1);
    y = func_h(X) + v;
    
    % PLOTS
    plot(X(1),X(2),'*r')
    axis([-2 4 0 6])
    hold on
    plot(x(1),x(2),'*b')
    hold off
    grid on
    pause(0.5)
    drawnow
    
end