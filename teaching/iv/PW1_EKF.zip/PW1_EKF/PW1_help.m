% Lecture: Intelligent Vehicles
% Professor: Dr. David Marquez-Gamez
% 2015 - 2016
%
% Exercise 1: Bayes Filter and EKF
% (a) Describe briefly the two main steps of the Bayes filter in your own words

% Exercise 2: Implement an EKF System
% (a) Using the file "PW1.m", your task is to implement an EKF system for the 
% problem of object Tracking described below
%
% Using an Extended Kalman Filter for Object Tracking
% 
% The main objectif of this practical work is to implement an Extended Kalman 
% Filter (EKF) for object tracking. The basic problem is shown in Figure 1.
%
%    ________
%   '        '
%   ' Object '
%   '________'
%       /|\
%        |
%        | 
%        |     Measurements
%        | (range and bearing)
%        |
%       \|/
%     ___'____       Noisy          _______    Estimated 
%    '        '   measurements     '       '   position
%    ' Sensor '------------------->'  EKF  '-------------->
%    '________'                    '_______'    
%
%       Figure 1. EKF and The problem of tracking objects.
% 
% At each point in time the object being tracked has a given range and bearing 
% from the observer. The observer is considered the location of a sensor 
% tracking the object. The range and bearing are generated from displacements 
% (i.e. distances from the observer) in both the x and y directions. 
% (this exercise does not consider the altitude of the object.)
%
% The tracking problem involves estimating not only the x and y displacements 
% of the object but also its x and y velocities. These four states must be 
% estimated given only noisy measurements of range and bearing. Given that 
% the displacements and velocities are non-linearly related to the range and 
% bearing this is an ideal problem to solve using an Extended Kalman Filter. 
%
%% 
%
% EKF: Extended Kalman Filter
%
%
% I. System
%
%   x+ = f ( x, u, n )
%   y  = h ( x ) + v
%
%   x : state vector           - P : cova. matrix
%   u : control vector
%   n : perturbation vector    - Q : cov. matrix
%   y : measurement vector
%   v : measuremet noise       - R : cov. matrix
%
%   f() : transition function
%   h() : measurement function
%
%
% II. Initialization
%
%   Define f(), and h().
%
%   Precise x, P, Q and R.
%
%
% III. Temporal loop
%
%   IIIa. Prediction of mean(x) and P at the arrival of u
%
%       Jacobian computation
%       F_x : jac. of x+ wrt. state
%       F_u : jac. of x+ wrt. control
%       F_n : jac. of x+ wrt. perturbation
%
%       x+ = f( x, u, 0 )
%       P+ = F_x * P * F_x' + F_n * Q * F_n'
%
%   IIIb. correction of mean(x) and P at the arrival of y
%
%       Jacobian computation
%       H   : jac. of y wrt. x
%
%       e  = h( x )          - expectation
%       E  = H * P * H'
%
%       z  = y - e          - innovation
%       Z  = R + E
%
%       K  = P * H' * Z^-1  - Kalman gain
%
%       x+ = x + K * z
%       P+ = P - K * H * P  //  P - K * Z * K' // and Joseph form
%
%
%   IV. Plot results
%
%
%   V. How to set up KF examples
%
%       1. Simulate system, get x, u and y trajectories
%
%       2. Estimate x with the KF. Get x and P trajectories.
%
%       3. Plot results.
